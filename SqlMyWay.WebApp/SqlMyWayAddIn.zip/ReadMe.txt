SQL My Way

A free, highly-configurable T-SQL formatter

For T-SQL programmers who have to deal with long and complicated queries,
"SQL My Way" is a SQL formatter that lets you format your SQL according to
one of several pre-defined standard formats or define your own format.
Unlike other SQL formatters, SQL My Way provides more options to allow you
to get your SQL looking exactly the way you like it. In addition, it is free,
fast, and very easy to configure and use.
